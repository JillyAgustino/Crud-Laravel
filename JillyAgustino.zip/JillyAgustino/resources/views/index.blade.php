<!DOCTYPE html>
<html>
<head>
	<title>Tutorial Membuat CRUD Pada Laravel</title>
</head>
<body>
 
	<h3>Data mahasiswa</h3>
 
	<a href="/mahasiswa/tambah"> + Tambah mahasiswa Baru</a>
	
	<br/>
	<br/>
 
	<table border="1">
		<tr>
			<th>Nama</th>
			<th>Nim</th>
			<th>Progdi</th>
		</tr>
		@foreach($pegawai as $p)
		<tr>
			<td>{{ $p->mahasiswa_nama }}</td>
			<td>{{ $p->mahasiswa_nim }}</td>
			<td>{{ $p->mahasiswa_progdi }}</td>
			<td>
				<a href="/mahasiswa/edit/{{ $p->mahasiswa_id }}">Edit</a>
				|
				<a href="/mahasiswa/hapus/{{ $p->mahasiswa_id }}">Hapus</a>
			</td>
		</tr>
	</table>
 
 
</body>
</html>